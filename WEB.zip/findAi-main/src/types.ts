export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  category: string;
  image: string;
  rating: number;
  reviews: number;
}

export interface Vacancy {
  id: string;
  title: string;
  company: string;
  location: string;
  salary: string;
  type: string;
  description: string;
  posted: string;
  logo: string;
}

export type SearchResult = Product | Vacancy;
export type Category = 'all' | 'products' | 'vacancies';