import SearchHeader from './components/SearchHeader';
import ResultsGrid from './components/ResultsGrid';
import { useSearch } from './hooks/useSearch';
import { CartProvider } from './context/CartContext';

function App() {
  const { 
    searchQuery, 
    setSearchQuery, 
    category, 
    setCategory, 
    results 
  } = useSearch();

  return (
    <CartProvider>
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
        <SearchHeader
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          category={category}
          onCategoryChange={setCategory}
        />
        
        <ResultsGrid results={results} />
        
        {/* Footer */}
        <footer className="bg-white border-t border-gray-200 mt-12 sm:mt-16">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
            <div className="text-center text-gray-600">
              <p className="mb-2 text-sm sm:text-base">© 2025 FindAI. Discover products and opportunities.</p>
            </div>
          </div>
        </footer>
      </div>
    </CartProvider>
  );
}

export default App;