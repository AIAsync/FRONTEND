import { useState, useMemo } from 'react';
import { SearchResult, Category, Product, Vacancy } from '../types';
import { mockProducts, mockVacancies } from '../data/mockData';

export function useSearch() {
  const [searchQuery, setSearchQuery] = useState('');
  const [category, setCategory] = useState<Category>('all');

  const filteredResults = useMemo(() => {
    let allResults: SearchResult[] = [];

    if (category === 'all' || category === 'products') {
      allResults.push(...mockProducts);
    }

    if (category === 'all' || category === 'vacancies') {
      allResults.push(...mockVacancies);
    }

    if (!searchQuery.trim()) {
      return allResults;
    }

    const query = searchQuery.toLowerCase();
    
    return allResults.filter((item) => {
      if ('price' in item) {
        // Product search
        const product = item as Product;
        return (
          product.title.toLowerCase().includes(query) ||
          product.description.toLowerCase().includes(query) ||
          product.category.toLowerCase().includes(query)
        );
      } else {
        // Vacancy search
        const vacancy = item as Vacancy;
        return (
          vacancy.title.toLowerCase().includes(query) ||
          vacancy.company.toLowerCase().includes(query) ||
          vacancy.location.toLowerCase().includes(query) ||
          vacancy.description.toLowerCase().includes(query)
        );
      }
    });
  }, [searchQuery, category]);

  return {
    searchQuery,
    setSearchQuery,
    category,
    setCategory,
    results: filteredResults,
  };
}