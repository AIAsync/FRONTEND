import { Product, Vacancy } from '../types';

export const mockProducts: Product[] = [
  {
    id: 'p1',
    title: 'MacBook Pro 16" M3',
    description: 'Latest MacBook Pro with M3 chip, 16GB RAM, 512GB SSD. Perfect for professional work.',
    price: 2499,
    category: 'Electronics',
    image: 'https://images.pexels.com/photos/205421/pexels-photo-205421.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.8,
    reviews: 234
  },
  {
    id: 'p2',
    title: 'Sony WH-1000XM5 Headphones',
    description: 'Industry-leading noise canceling with exceptional sound quality.',
    price: 399,
    category: 'Audio',
    image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.7,
    reviews: 892
  },
  {
    id: 'p3',
    title: 'iPhone 15 Pro Max',
    description: 'The ultimate iPhone with titanium design and A17 Pro chip.',
    price: 1199,
    category: 'Mobile',
    image: 'https://images.pexels.com/photos/788946/pexels-photo-788946.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.9,
    reviews: 1523
  },
  {
    id: 'p4',
    title: 'Gaming Chair Pro',
    description: 'Ergonomic gaming chair with lumbar support and premium materials.',
    price: 299,
    category: 'Furniture',
    image: 'https://images.pexels.com/photos/4050317/pexels-photo-4050317.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.5,
    reviews: 156
  },
  {
    id: 'p5',
    title: 'Smart Watch Series 9',
    description: 'Advanced health tracking with bright always-on display.',
    price: 429,
    category: 'Wearables',
    image: 'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.6,
    reviews: 678
  },
  {
    id: 'p6',
    title: 'Wireless Keyboard & Mouse Set',
    description: 'Premium wireless combo with mechanical keys and precision mouse.',
    price: 159,
    category: 'Accessories',
    image: 'https://images.pexels.com/photos/2148217/pexels-photo-2148217.jpeg?auto=compress&cs=tinysrgb&w=400',
    rating: 4.4,
    reviews: 445
  }
];

export const mockVacancies: Vacancy[] = [
  {
    id: 'v1',
    title: 'Senior Frontend Developer',
    company: 'TechCorp Inc.',
    location: 'San Francisco, CA',
    salary: '$120k - $160k',
    type: 'Full-time',
    description: 'Looking for an experienced React developer to join our growing team.',
    posted: '2 days ago',
    logo: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=200'
  },
  {
    id: 'v2',
    title: 'UX/UI Designer',
    company: 'Design Studio',
    location: 'New York, NY',
    salary: '$90k - $120k',
    type: 'Full-time',
    description: 'Create beautiful and intuitive user experiences for our clients.',
    posted: '1 week ago',
    logo: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=200'
  },
  {
    id: 'v3',
    title: 'Data Scientist',
    company: 'AI Solutions',
    location: 'Seattle, WA',
    salary: '$130k - $170k',
    type: 'Full-time',
    description: 'Work with machine learning models and big data analytics.',
    posted: '3 days ago',
    logo: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=200'
  },
  {
    id: 'v4',
    title: 'Product Manager',
    company: 'StartupXYZ',
    location: 'Austin, TX',
    salary: '$110k - $140k',
    type: 'Full-time',
    description: 'Lead product strategy and work cross-functionally with engineering.',
    posted: '5 days ago',
    logo: 'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=200'
  },
  {
    id: 'v5',
    title: 'DevOps Engineer',
    company: 'CloudTech',
    location: 'Remote',
    salary: '$100k - $140k',
    type: 'Remote',
    description: 'Manage infrastructure and deployment pipelines in cloud environments.',
    posted: '1 day ago',
    logo: 'https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg?auto=compress&cs=tinysrgb&w=200'
  },
  {
    id: 'v6',
    title: 'Marketing Specialist',
    company: 'GrowthCo',
    location: 'Los Angeles, CA',
    salary: '$70k - $90k',
    type: 'Full-time',
    description: 'Drive digital marketing campaigns and analyze performance metrics.',
    posted: '1 week ago',
    logo: 'https://images.pexels.com/photos/3184394/pexels-photo-3184394.jpeg?auto=compress&cs=tinysrgb&w=200'
  }
];