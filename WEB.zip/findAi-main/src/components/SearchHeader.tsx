import { Search } from "lucide-react";
import { Category } from "../types";
import CartIcon from "./CartIcon";

interface SearchHeaderProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  category: Category;
  onCategoryChange: (category: Category) => void;
}

export default function SearchHeader({
  searchQuery,
  onSearchChange,
  category,
  onCategoryChange,
}: SearchHeaderProps) {
  return (
    <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-purple-800 text-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        <div className="flex items-center justify-between mb-6 sm:mb-8">
          <div className="text-left">
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold bg-gradient-to-r from-white to-blue-100 bg-clip-text text-transparent">
              FindAI
            </h1>
            <p className="text-blue-100 text-xs sm:text-sm md:text-base mt-1">
              Discover products & opportunities
            </p>
          </div>
          <div id="app-cart-anchor">
            <CartIcon />
          </div>
        </div>

        {/* Search Bar */}
        <div className="relative max-w-2xl mx-auto mb-6 sm:mb-8">
          <div className="relative">
            <Search className="absolute left-3 sm:left-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4 sm:h-5 sm:w-5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search products, jobs..."
              className="w-full pl-10 sm:pl-12 pr-4 sm:pr-6 py-3 sm:py-4 rounded-xl sm:rounded-2xl text-gray-900 placeholder-gray-500 
                       backdrop-blur-sm bg-white/90 border-0 focus:ring-2 focus:ring-white/50 
                       focus:outline-none shadow-2xl text-sm sm:text-base md:text-lg transition-all duration-300
                       hover:bg-white/95 focus:bg-white"
            />
          </div>
        </div>

        {/* Category Filters */}
        <div className="flex justify-center space-x-1 sm:space-x-2 overflow-x-auto pb-2">
          {[
            { key: "all", label: "All Results" },
            { key: "products", label: "Products" },
            { key: "vacancies", label: "Vacancies" },
          ].map(({ key, label }) => (
            <button
              key={key}
              onClick={() => onCategoryChange(key as Category)}
              className={`px-3 sm:px-6 py-2 rounded-full font-medium transition-all duration-300 whitespace-nowrap text-sm sm:text-base ${
                category === key
                  ? "bg-white text-blue-700 shadow-lg transform scale-105"
                  : "bg-white/20 text-white hover:bg-white/30 hover:scale-105"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
