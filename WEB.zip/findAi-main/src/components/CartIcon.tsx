import { ShoppingCart } from 'lucide-react';
import { useCart } from '../context/CartContext';

interface CartIconProps {
  onClick?: () => void;
}

export default function CartIcon({ onClick }: CartIconProps) {
  const { totalItems } = useCart();

  return (
    <button
      onClick={onClick}
      aria-label="Cart"
      className="relative inline-flex items-center justify-center p-2 rounded-xl bg-white/20 hover:bg-white/30 transition-colors"
    >
      <ShoppingCart className="h-6 w-6 text-white" />
      {totalItems > 0 && (
        <span
          className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold rounded-full px-1.5 py-0.5 min-w-[20px] text-center"
        >
          {totalItems}
        </span>
      )}
    </button>
  );
}


