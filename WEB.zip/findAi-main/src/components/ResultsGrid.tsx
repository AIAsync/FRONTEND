import { Product, Vacancy, SearchResult } from '../types';
import ProductCard from './ProductCard';
import VacancyCard from './VacancyCard';
import { Package, Briefcase } from 'lucide-react';

interface ResultsGridProps {
  results: SearchResult[];
  isLoading?: boolean;
}

function isProduct(item: SearchResult): item is Product {
  return 'price' in item;
}

export default function ResultsGrid({ results, isLoading }: ResultsGridProps) {
  if (isLoading) {
    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
          {Array(6).fill(0).map((_, index) => (
            <div key={index} className="bg-gray-200 rounded-xl sm:rounded-2xl h-80 sm:h-96 animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  if (results.length === 0) {
    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12 sm:py-20 text-center">
        <div className="bg-white rounded-xl sm:rounded-2xl shadow-lg p-6 sm:p-12">
          <div className="text-gray-400 mb-4">
            <Package className="h-12 w-12 sm:h-16 sm:w-16 mx-auto mb-4" />
          </div>
          <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-2">No results found</h3>
          <p className="text-gray-600 text-sm sm:text-base">Try adjusting your search terms or filters.</p>
        </div>
      </div>
    );
  }

  const products = results.filter(isProduct);
  const vacancies = results.filter(item => !isProduct(item)) as Vacancy[];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
      {/* Products Section */}
      {products.length > 0 && (
        <div className="mb-8 sm:mb-12">
          <div className="flex items-center mb-4 sm:mb-6">
            <Package className="h-5 w-5 sm:h-6 sm:w-6 text-blue-600 mr-2 sm:mr-3" />
            <h2 className="text-xl sm:text-2xl font-bold text-gray-900">Products ({products.length})</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      )}

      {/* Vacancies Section */}
      {vacancies.length > 0 && (
        <div>
          <div className="flex items-center mb-4 sm:mb-6">
            <Briefcase className="h-5 w-5 sm:h-6 sm:w-6 text-teal-600 mr-2 sm:mr-3" />
            <h2 className="text-xl sm:text-2xl font-bold text-gray-900">Job Vacancies ({vacancies.length})</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8">
            {vacancies.map((vacancy) => (
              <VacancyCard key={vacancy.id} vacancy={vacancy} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}