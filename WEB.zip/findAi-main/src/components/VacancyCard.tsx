import  { useState } from 'react';
import { MapPin, Clock, DollarSign, Building } from 'lucide-react';
import { Vacancy } from '../types';
import ApplyModal from './ApplyModal';

interface VacancyCardProps {
  vacancy: Vacancy;
}

export default function VacancyCard({ vacancy }: VacancyCardProps) {
  const [open, setOpen] = useState(false);
  return (
    <div className="bg-white rounded-xl sm:rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 
                    transform hover:scale-105 hover:-translate-y-1 overflow-hidden group p-4 sm:p-6">
      
      <div className="flex items-start justify-between mb-3 sm:mb-4">
        <div className="flex items-center space-x-3 sm:space-x-4 flex-1 min-w-0">
          <div className="relative flex-shrink-0">
            <img 
              src={vacancy.logo} 
              alt={`${vacancy.company} logo`}
              className="w-12 h-12 sm:w-14 sm:h-14 rounded-lg sm:rounded-xl object-cover shadow-md"
            />
          </div>
          <div className="min-w-0 flex-1">
            <h3 className="text-lg sm:text-xl font-bold text-gray-900 group-hover:text-blue-600 transition-colors truncate">
              {vacancy.title}
            </h3>
            <div className="flex items-center text-gray-600 mt-1">
              <Building className="h-3 w-3 sm:h-4 sm:w-4 mr-1 flex-shrink-0" />
              <span className="font-medium text-sm sm:text-base truncate">{vacancy.company}</span>
            </div>
          </div>
        </div>
        
        <div className={`px-2 sm:px-3 py-1 rounded-full text-xs font-semibold flex-shrink-0 ml-2 ${
          vacancy.type === 'Remote' 
            ? 'bg-green-100 text-green-700'
            : 'bg-blue-100 text-blue-700'
        }`}>
          {vacancy.type}
        </div>
      </div>
      
      <p className="text-gray-600 mb-3 sm:mb-4 line-clamp-2 leading-relaxed text-sm sm:text-base">
        {vacancy.description}
      </p>
      
      <div className="space-y-2 sm:space-y-3 mb-4 sm:mb-6">
        <div className="flex items-center text-gray-600">
          <MapPin className="h-3 w-3 sm:h-4 sm:w-4 mr-2 text-blue-500 flex-shrink-0" />
          <span className="text-sm sm:text-base truncate">{vacancy.location}</span>
        </div>
        
        <div className="flex items-center text-gray-600">
          <DollarSign className="h-3 w-3 sm:h-4 sm:w-4 mr-2 text-green-500 flex-shrink-0" />
          <span className="font-semibold text-sm sm:text-base">{vacancy.salary}</span>
        </div>
        
        <div className="flex items-center text-gray-600">
          <Clock className="h-3 w-3 sm:h-4 sm:w-4 mr-2 text-orange-500 flex-shrink-0" />
          <span className="text-sm sm:text-base">Posted {vacancy.posted}</span>
        </div>
      </div>
      
      <button onClick={() => setOpen(true)} className="w-full bg-gradient-to-r from-teal-600 to-teal-700 hover:from-teal-700 
                         hover:to-teal-800 text-white font-semibold py-2.5 sm:py-3 px-3 sm:px-4 rounded-lg sm:rounded-xl 
                         transition-all duration-300 transform hover:scale-105 
                         group-hover:shadow-lg text-sm sm:text-base">
        Apply Now
      </button>
      <ApplyModal open={open} onClose={() => setOpen(false)} vacancyTitle={vacancy.title} />
    </div>
  );
}