import { useRef } from "react";
import { Star, ShoppingCart } from "lucide-react";
import { Product } from "../types";
import { useCart } from "../context/CartContext";

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addItem } = useCart();
  const imgRef = useRef<HTMLImageElement | null>(null);

  const handleAddToCart = () => {
    addItem(product);

    const imgEl = imgRef.current;
    const cartEl = document.getElementById("app-cart-anchor");
    if (!imgEl || !cartEl) return;

    const imgRect = imgEl.getBoundingClientRect();
    const cartRect = cartEl.getBoundingClientRect();

    const clone = imgEl.cloneNode(true) as HTMLImageElement;
    clone.style.position = "fixed";
    clone.style.left = `${imgRect.left}px`;
    clone.style.top = `${imgRect.top}px`;
    clone.style.width = `${imgRect.width}px`;
    clone.style.height = `${imgRect.height}px`;
    clone.style.borderRadius = "12px";
    clone.style.zIndex = "9999";
    clone.style.transition =
      "transform 600ms cubic-bezier(0.22, 1, 0.36, 1), opacity 600ms";
    document.body.appendChild(clone);

    const translateX =
      cartRect.left + cartRect.width / 2 - (imgRect.left + imgRect.width / 2);
    const translateY =
      cartRect.top + cartRect.height / 2 - (imgRect.top + imgRect.height / 2);

    requestAnimationFrame(() => {
      clone.style.transform = `translate(${translateX}px, ${translateY}px) scale(0.2)`;
      clone.style.opacity = "0.3";
    });

    setTimeout(() => {
      clone.remove();
    }, 650);
  };
  return (
    <div
      className="bg-white rounded-xl sm:rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 
                    transform hover:scale-105 hover:-translate-y-1 overflow-hidden group"
    >
      <div className="relative overflow-hidden">
        <img
          ref={imgRef}
          src={product.image}
          alt={product.title}
          className="w-full h-40 sm:h-48 object-cover group-hover:scale-110 transition-transform duration-300"
        />
        <div
          className="absolute top-2 sm:top-4 right-2 sm:right-4 bg-white/90 backdrop-blur-sm rounded-full px-2 sm:px-3 py-1 
                        text-xs sm:text-sm font-semibold text-gray-700"
        >
          {product.category}
        </div>
      </div>

      <div className="p-4 sm:p-6">
        <h3 className="text-lg sm:text-xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
          {product.title}
        </h3>

        <p className="text-gray-600 mb-3 sm:mb-4 line-clamp-2 leading-relaxed text-sm sm:text-base">
          {product.description}
        </p>

        <div className="flex items-center justify-between mb-3 sm:mb-4">
          <div className="flex items-center space-x-1">
            <Star className="h-3 w-3 sm:h-4 sm:w-4 text-yellow-400 fill-current" />
            <span className="text-xs sm:text-sm font-medium text-gray-700">
              {product.rating} ({product.reviews})
            </span>
          </div>
          <div className="text-lg sm:text-2xl font-bold text-blue-600">
            ${product.price.toLocaleString()}
          </div>
        </div>

        <button
          onClick={handleAddToCart}
          className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 
                           hover:to-blue-800 text-white font-semibold py-2.5 sm:py-3 px-3 sm:px-4 rounded-lg sm:rounded-xl 
                           transition-all duration-300 flex items-center justify-center space-x-2 
                           group-hover:shadow-lg transform hover:scale-105 text-sm sm:text-base"
        >
          <ShoppingCart className="h-4 w-4 sm:h-5 sm:w-5" />
          <span>Add to Cart</span>
        </button>
      </div>
    </div>
  );
}
