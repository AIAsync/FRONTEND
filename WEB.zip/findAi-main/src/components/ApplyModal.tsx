import { useState, useEffect } from 'react';
import { X, Calendar, User, Mail, Phone } from 'lucide-react';

interface ApplyModalProps {
  open: boolean;
  onClose: () => void;
  vacancyTitle?: string;
}

export default function ApplyModal({ open, onClose, vacancyTitle }: ApplyModalProps) {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [datetime, setDatetime] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState<{[key: string]: string}>({});
  const [success, setSuccess] = useState(false);

  // Reset form when modal opens/closes
  useEffect(() => {
    if (open) {
      setFullName('');
      setEmail('');
      setPhone('');
      setDatetime('');
      setErrors({});
      setSuccess(false);
    }
  }, [open]);

  // Set minimum datetime to current time
  useEffect(() => {
    if (open && !datetime) {
      const now = new Date();
      now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
      setDatetime(now.toISOString().slice(0, 16));
    }
  }, [open, datetime]);

  const validateForm = () => {
    const newErrors: {[key: string]: string} = {};
    
    if (!fullName.trim()) {
      newErrors.fullName = 'Full name is required';
    }
    
    if (!email.trim()) {
      newErrors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      newErrors.email = 'Please enter a valid email';
    }
    
    if (!phone.trim()) {
      newErrors.phone = 'Phone number is required';
    }
    
    if (!datetime) {
      newErrors.datetime = 'Please select a date and time';
    } else {
      const selectedDate = new Date(datetime);
      const now = new Date();
      if (selectedDate <= now) {
        newErrors.datetime = 'Please select a future date and time';
      }
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleConfirm = async () => {
    if (!validateForm()) return;
    
    setSubmitting(true);
    const payload = { 
      fullName: fullName.trim(), 
      email: email.trim(), 
      phone: phone.trim(), 
      datetime, 
      vacancyTitle,
      submittedAt: new Date().toISOString()
    };
    
    try {
      // Try to send to backend first
      try {
        const response = await fetch('/api/meetings', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        
        if (!response.ok) {
          throw new Error('Failed to submit');
        }
      } catch {
        // Fallback to console log
        console.log('Meeting application submitted:', payload);
      }
      
      setSuccess(true);
      setTimeout(() => {
        onClose();
      }, 2000);
      
    } catch (error) {
      console.error('Error submitting application:', error);
      alert('There was an error submitting your application. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  if (!open) return null;

  if (success) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4">
        <div className="absolute inset-0 bg-black/40" />
        <div className="relative w-full max-w-md bg-white rounded-xl sm:rounded-2xl shadow-2xl p-6 sm:p-8 text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h3 className="text-xl sm:text-2xl font-bold text-gray-900 mb-2">Meeting Scheduled!</h3>
          <p className="text-gray-600 mb-4">Your meeting has been successfully scheduled. We'll contact you soon!</p>
          <div className="text-sm text-gray-500">
            <p>Position: <span className="font-medium">{vacancyTitle}</span></p>
            <p>Date: <span className="font-medium">{new Date(datetime).toLocaleString()}</span></p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />

      <div className="relative w-full max-w-lg bg-white rounded-xl sm:rounded-2xl shadow-2xl p-4 sm:p-6 md:p-8 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-xl sm:text-2xl font-bold text-gray-900">Schedule a Meeting</h3>
            {vacancyTitle && (
              <p className="text-sm text-gray-600 mt-1">Position: <span className="font-medium text-teal-600">{vacancyTitle}</span></p>
            )}
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <form onSubmit={(e) => { e.preventDefault(); handleConfirm(); }} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <User className="inline h-4 w-4 mr-1" />
              Full Name *
            </label>
            <input 
              value={fullName} 
              onChange={(e) => setFullName(e.target.value)} 
              className={`w-full border rounded-lg sm:rounded-xl px-3 sm:px-4 py-2.5 sm:py-3 focus:outline-none focus:ring-2 text-sm sm:text-base ${
                errors.fullName 
                  ? 'border-red-300 focus:ring-red-500' 
                  : 'border-gray-300 focus:ring-teal-500'
              }`}
              placeholder="Enter your full name" 
            />
            {errors.fullName && <p className="text-red-500 text-xs mt-1">{errors.fullName}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Mail className="inline h-4 w-4 mr-1" />
              Email Address *
            </label>
            <input 
              type="email" 
              value={email} 
              onChange={(e) => setEmail(e.target.value)} 
              className={`w-full border rounded-lg sm:rounded-xl px-3 sm:px-4 py-2.5 sm:py-3 focus:outline-none focus:ring-2 text-sm sm:text-base ${
                errors.email 
                  ? 'border-red-300 focus:ring-red-500' 
                  : 'border-gray-300 focus:ring-teal-500'
              }`}
              placeholder="your.email@example.com" 
            />
            {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Phone className="inline h-4 w-4 mr-1" />
              Phone Number *
            </label>
            <input 
              value={phone} 
              onChange={(e) => setPhone(e.target.value)} 
              className={`w-full border rounded-lg sm:rounded-xl px-3 sm:px-4 py-2.5 sm:py-3 focus:outline-none focus:ring-2 text-sm sm:text-base ${
                errors.phone 
                  ? 'border-red-300 focus:ring-red-500' 
                  : 'border-gray-300 focus:ring-teal-500'
              }`}
              placeholder="+1 (555) 123-4567" 
            />
            {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <Calendar className="inline h-4 w-4 mr-1" />
              Preferred Date & Time *
            </label>
            <input 
              type="datetime-local" 
              value={datetime} 
              onChange={(e) => setDatetime(e.target.value)} 
              min={new Date().toISOString().slice(0, 16)}
              className={`w-full border rounded-lg sm:rounded-xl px-3 sm:px-4 py-2.5 sm:py-3 focus:outline-none focus:ring-2 text-sm sm:text-base ${
                errors.datetime 
                  ? 'border-red-300 focus:ring-red-500' 
                  : 'border-gray-300 focus:ring-teal-500'
              }`}
            />
            {errors.datetime && <p className="text-red-500 text-xs mt-1">{errors.datetime}</p>}
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-end gap-2 sm:gap-3 pt-4">
            <button 
              type="button"
              onClick={onClose} 
              className="px-4 py-2.5 sm:py-2 rounded-lg sm:rounded-xl border border-gray-300 text-gray-700 hover:bg-gray-50 text-sm sm:text-base order-2 sm:order-1"
            >
              Cancel
            </button>
            <button 
              type="submit"
              disabled={submitting} 
              className="px-4 py-2.5 sm:py-2 rounded-lg sm:rounded-xl bg-teal-600 hover:bg-teal-700 text-white disabled:opacity-60 text-sm sm:text-base order-1 sm:order-2 flex items-center justify-center gap-2"
            >
              {submitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Scheduling...
                </>
              ) : (
                <>
                  <Calendar className="h-4 w-4" />
                  Confirm Meeting
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}


